#!/bin/bash

oc login --username=ocadmin --password=ibmocp46 --insecure-skip-tls-verify=true --server=https://api.ocp.ibm.edu:6443
oc project websphere-automation

echo https://"$(oc get route cpd -n websphere-automation -o jsonpath='{.spec.host}')"/websphereauto/meteringapi >/opt/IBM/WebSphere/metering-url.txt

oc -n websphere-automation get secret automation-secure-metering-apis-encrypted-tokens -o jsonpath='{.data.automation-secure-metering-apis-sa}' | base64 -d >/opt/IBM/WebSphere/api-key.txt
echo >>/opt/IBM/WebSphere/api-key.txt

oc get secret external-tls-secret -n websphere-automation -o jsonpath='{.data.cert\.crt}' | base64 -d >/opt/IBM/WebSphere/cacert.pem

/opt/IBM/WebSphere/Liberty200012/bin/server create Liberty_200012_server
cp /home/ibmuser/Desktop/lab_backup/liberty200012/server_tls.xml /opt/IBM/WebSphere/Liberty200012/usr/servers/Liberty_200012_server/server.xml
/opt/IBM/WebSphere/Liberty200012/bin/server start Liberty_200012_server
keytool -import -trustcacerts -file /opt/IBM/WebSphere/cacert.pem -keystore /opt/IBM/WebSphere/Liberty200012/usr/servers/Liberty_200012_server/resources/security/key.p12 -storetype PKCS12 -storepass th1nkpassword -noprompt
cp /home/ibmuser/Desktop/lab_backup/liberty200012/server_configured.xml /opt/IBM/WebSphere/Liberty200012/usr/servers/Liberty_200012_server/server.xml

/opt/IBM/WebSphere/Liberty20009/bin/server create Liberty_20009_server
cp /home/ibmuser/Desktop/lab_backup/liberty20009/server_tls.xml /opt/IBM/WebSphere/Liberty20009/usr/servers/Liberty_20009_server/server.xml
/opt/IBM/WebSphere/Liberty20009/bin/server start Liberty_20009_server
keytool -import -trustcacerts -file /opt/IBM/WebSphere/cacert.pem -keystore /opt/IBM/WebSphere/Liberty20009/usr/servers/Liberty_20009_server/resources/security/key.p12 -storetype PKCS12 -storepass th1nkpassword -noprompt
cp /home/ibmuser/Desktop/lab_backup/liberty20009/server_configured.xml /opt/IBM/WebSphere/Liberty20009/usr/servers/Liberty_20009_server/server.xml

/opt/IBM/WebSphere/AppServer9056/bin/startServer.sh tWAS_9056_server
/opt/IBM/WebSphere/AppServer9056/bin/wsadmin.sh -f /api-usagemetering/scripts/configuretWasUsageMetering.py url=$(cat /opt/IBM/WebSphere/metering-url.txt) apiKey=$(cat /opt/IBM/WebSphere/api-key.txt) trustStorePassword=th1nkpassword

/opt/IBM/WebSphere/AppServer9057/bin/startServer.sh tWAS_9057_server
/opt/IBM/WebSphere/AppServer9057/bin/wsadmin.sh -f /api-usagemetering/scripts/configuretWasUsageMetering.py url=$(cat /opt/IBM/WebSphere/metering-url.txt) apiKey=$(cat /opt/IBM/WebSphere/api-key.txt) trustStorePassword=th1nkpassword

